try:
    from flask import Flask, render_template, request,jsonify
    from flask_pymongo import PyMongo
    import pandas as pd
    import numpy as np
    import json
    import os
except Exception as ex:
    print("Problem occured while importing module")

app = Flask(__name__)
app.config['MONGO_URI']="mongodb://localhost:27017/Movie"
mongo = PyMongo(app)

table_name = mongo.db.table_movie

@app.route('/')
def home():
    return render_template('Home.html')

 # .xsv and .json file must in the current dirrectory to upload into database
@app.route('/UploadData', methods = ['POST'])
def UploadData():
    message=""
    if request.method == 'POST':
        file_data = request.form['file_name']
        option = request.form['selected_option']

        if(isCorrectFormate(file_data) == option):
            table = mongo.db.table_movie

            if option == '.csv':
                try:
                    data = pd.read_csv(file_data)
                    data = data.replace(np.nan,0)
                    result = data.to_dict('records')
                    table.insert_many(result,ordered=False)
                    message = file_data + " Data uploded"
                except:
                    message = "Unable to upload a CSV file data "
            elif option == '.json':
                try:
                    data = pd.read_json(file_data)
                    data = data.replace(np.nan,0)
                    result = data.to_dict('records')
                    table.insert_many(result,ordered=False)
                    message = file_data + " Data uploded"
                except:
                    message = "Unable to upload json file data"
            else:
                message = "Contact to admin !"
        else:
            message = file_data + " extension  and " + option + " must be the same "
    else:
        message = "This page accept only POST request"
    
    message += "<br><br><a href = '/' >click here to go back to previous page</a>"
    return message

def isCorrectFormate(ext):
    name,extensions = os.path.splitext(ext)
    return extensions


@app.route('/view',methods = ['GET'])
def view():
    
    result = table_name.find()
    data = pd.DataFrame(result)
    return render_template('Home.html',viewResult = data.to_html(header=True,index=False))

if __name__== "__main__":
    app.run(debug=True)
