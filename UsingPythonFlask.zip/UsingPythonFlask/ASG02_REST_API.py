try:
    from flask import Flask,jsonify
    from flask_pymongo import PyMongo
    import pandas as pd
except:
    print("Unable to import modules")

app = Flask(__name__)

try:

    app.config['MONGO_URI']="mongodb://localhost:27017/Movie"
    mongo = PyMongo(app)
    table_name = mongo.db.table_movie
except:
    print("Unable to connect with database")

if __name__ == '__main__':
    app.run(debug=True)


@app.route('/')
def home():
    return "<h1>kindly append  /getData  in the URL to seethe Data </h1>"

# using 127.0.0.1:5000/getData
# you can make use of postman to see the output by typing above address
@app.route('/getData',methods =['GET'])
def getData():
    output = []
    cnt  = 1
    for q in table_name.find():
        dic= {}
        for j in q.keys():
            if cnt == 1:
                cnt = 0
            else:
                dic[j] = q[j]
        cnt = 1
        output.append(dic)

    return jsonify(output)